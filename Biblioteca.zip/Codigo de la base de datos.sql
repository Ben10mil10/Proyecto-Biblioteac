-- Crea solo la base primero, luego lo demas.
    CREATE DATABASE BibliotecaDB


Use BibliotecaDB;

Create table Libros (
    ISBN char(13) primary key,
    Titulo nvarchar(255) not null,
    Autor nvarchar(255) not null,
    Editorial nvarchar(255),
    A�oPublicacion int,
    Genero nvarchar(100),
    NumeroCopias int default 1
);

Create table Usuarios (
    IDUsuario int primary key identity(1,1),
    Nombre nvarchar(100) not null,
    Apellido nvarchar(100) not null,
    Email nvarchar(255) unique not null,
    Telefono nvarchar(15)
);


Create table Reservas (
    IDReserva int primary key identity(1,1), 
    IDUsuario int not null,
    ISBN char(13) not null,
    FechaReserva date not null,
    FechaRetorno date not null,

    CONSTRAINT FK_Reserva_Usuario FOREIGN KEY (IDUsuario)
        REFERENCES Usuarios(IDUsuario) ON DELETE CASCADE, 
    CONSTRAINT FK_Reserva_Libro FOREIGN KEY (ISBN)
        REFERENCES Libros(ISBN) ON DELETE CASCADE
);

INSERT INTO Libros (ISBN, Titulo, Autor, Editorial, A�oPublicacion, Genero, NumeroCopias)
VALUES
('9780140449136', 'The Odyssey', 'Homer', 'Penguin Classics', 1996, 'Epic Poetry', 5),
('9780345803481', 'Fifty Shades of Grey', 'E. L. James', 'Vintage', 2012, 'Romance', 10),
('9780590353427', 'Harry Potter and the Sorcerer''s Stone', 'J.K. Rowling', 'Scholastic', 1998, 'Fantasy', 20),
('9780679783275', 'Pride and Prejudice', 'Jane Austen', 'Modern Library', 1995, 'Classic Literature', 7),
('9780553296983', 'Dune', 'Frank Herbert', 'Ace', 1990, 'Science Fiction', 8);

INSERT INTO Usuarios (Nombre, Apellido, Email, Telefono)
VALUES
('Juan', 'P�rez', 'juan.perez@email.com', '8091234567'),
('Mar�a', 'Rodr�guez', 'maria.rodriguez@email.com', '8099876543'),
('Carlos', 'Santos', 'carlos.santos@email.com', '8097654321');

INSERT INTO Reservas (IDUsuario, ISBN, FechaReserva, FechaRetorno)
VALUES
(1, '9780140449136', '2024-10-01', '2024-10-15'),
(2, '9780345803481', '2024-10-05', '2024-10-20'),
(3, '9780590353427', '2024-10-10', '2024-10-24');
