﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Biblioteca
{
    public partial class Reserva : Form
    {

        string IDRESERVA;

        private ConexionBiblioteca conexionDB = new ConexionBiblioteca();

        public Reserva()
        {
            InitializeComponent();
            CargarReserva();
            CargarLibros();
            CargarUsuarios();
        }

        private void eliminar_reserva_Click(object sender, EventArgs e)
        {

        }

        private void CargarReserva()
        {
            string query = "Select R.IDReserva, R.IDUsuario, (U.Nombre + '' + U.Apellido)AS Usuario, R.ISBN, L.Titulo, R.FechaReserva, R.FechaRetorno from Reservas R JOIN Usuarios U ON R.IDUsuario = U.IDUsuario JOIN Libros L ON R.ISBN = L.ISBN";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                
                dataGridView1.DataSource = dt;
            }
        }

        private void CargarLibros()
        {
            string query = "Select ISBN, Titulo from Libros";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "Titulo";
                    comboBox1.ValueMember = "ISBN"; ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar libros: " + ex.Message);
                }
            }
        }

        private void CargarUsuarios()
        {
            string query = "Select IDUsuario, (Nombre+' '+Apellido)as 'usuario' from Usuarios";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                   
                    comboBox2.DataSource = dt;
                    comboBox2.DisplayMember = "usuario";
                    comboBox2.ValueMember = "IDUsuario";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar usuarios: " + ex.Message);
                }
            }
        }
        private void Reserva_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'bibliotecaDBDataSet.Libros' Puede moverla o quitarla según sea necesario.
            this.librosTableAdapter.Fill(this.bibliotecaDBDataSet.Libros);
            // TODO: esta línea de código carga datos en la tabla 'bibliotecaDBDataSet.Reservas' Puede moverla o quitarla según sea necesario.
            this.reservasTableAdapter.Fill(this.bibliotecaDBDataSet.Reservas);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void agregar_libros_Click(object sender, EventArgs e)
        {
            string query = "Insert Into Reservas (IDUsuario, ISBN, FechaReserva, FechaRetorno) " +
                   "values (@IDUsuario, @ISBN, @FechaReserva, @FechaRetorno)";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IDUsuario", comboBox2.SelectedValue);
                cmd.Parameters.AddWithValue("@ISBN", comboBox1.SelectedValue);
                cmd.Parameters.AddWithValue("@FechaReserva", dateTimePicker1.Value);
                cmd.Parameters.AddWithValue("@FechaRetorno", dateTimePicker2.Value);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Reserva agregado correctamente");
                    CargarReserva();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al agregar el reserva: " + ex.Message);
                }
            }
        }

        private void eliminar_libros_Click(object sender, EventArgs e)
        {
            string query = "Delete from Reservas where IDReserva = @IDReserva";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IDReserva", dataGridView1.CurrentRow.Cells["IDReserva"].Value); 

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Reserva eliminada correctamente");
                    CargarReserva();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar la reserva: " + ex.Message);
                }
            }
        }

        private void editar_usuario_Click(object sender, EventArgs e)
        {
            string query = "Update Reservas set IDUsuario = @IDUsuario, ISBN = @ISBN, FechaReserva = @FechaReserva, " +
                   "FechaRetorno = @FechaRetorno where IDReserva = @IDReserva";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IDReserva", IDRESERVA);
                cmd.Parameters.AddWithValue("@IDUsuario", comboBox2.SelectedValue);
                cmd.Parameters.AddWithValue("@ISBN", comboBox1.SelectedValue);
                cmd.Parameters.AddWithValue("@FechaReserva", dateTimePicker1.Value);
                cmd.Parameters.AddWithValue("@FechaRetorno", dateTimePicker2.Value);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Reserva actualizada correctamente");
                    CargarReserva();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar la reserva: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                IDRESERVA = row.Cells["IDReserva"].Value.ToString();

                comboBox2.SelectedValue = row.Cells["IDUsuario"].Value;

                comboBox1.SelectedValue = row.Cells["ISBN"].Value;

                dateTimePicker1.Value = Convert.ToDateTime(row.Cells["FechaReserva"].Value);

                dateTimePicker2.Value = Convert.ToDateTime(row.Cells["FechaRetorno"].Value);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
