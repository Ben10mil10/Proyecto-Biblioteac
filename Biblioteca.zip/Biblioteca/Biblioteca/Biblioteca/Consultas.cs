﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Biblioteca
{
    public partial class Consultas : Form
    {

        private ConexionBiblioteca conexionDB = new ConexionBiblioteca();
        public Consultas()
        {
            InitializeComponent();
            CargarLibros();
            Cargar1();
            Cargar2();
            Cargar3();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void CargarLibros()
        {
            string query = "Select distinct Genero from Libros";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "Genero";
                    comboBox1.ValueMember = "Genero";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar libros: " + ex.Message);
                }
            }
        }
        private void Cargar1()
        {
            string query = "Select * from Libros where Genero=@Genero and NumeroCopias>0";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Genero", comboBox1.SelectedValue);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
            }
        }

        private void Cargar2()
        {
            string query = "Select L.ISBN, L.Titulo, count(R.ISBN) as TotalReservas from Libros L join Reservas R on L.ISBN = R.ISBN Group by L.ISBN, L.Titulo order by TotalReservas desc";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Genero", comboBox1.SelectedValue);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView2.DataSource = dt;
            }
        }

        private void Cargar3()
        {
            string query = "Select U.IDUsuario, U.Nombre, U.Apellido From Usuarios U join Reservas R on U.IDUsuario = R.IDUsuario Group by U.IDUsuario, U.Nombre, U.Apellido order by count(R.IDUsuario) desc";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Genero", comboBox1.SelectedValue);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView3.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Cargar1();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Consultas_Load(object sender, EventArgs e)
        {

        }
    }
}
