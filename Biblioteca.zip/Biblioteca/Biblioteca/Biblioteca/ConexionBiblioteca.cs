﻿using System;
using System.Data.SqlClient;

namespace Biblioteca
{
    public class ConexionBiblioteca
    {
        private static string connectionString = "Server=localhost\\SQLEXPRESS; Initial Catalog=BibliotecaDB; Integrated Security=True;";

        public SqlConnection Conectar()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
                return conn;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al conectar a la base de datos: " + ex.Message);
            }
        }
    }
}
