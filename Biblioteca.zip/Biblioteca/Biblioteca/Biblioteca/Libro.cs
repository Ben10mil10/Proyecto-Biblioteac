﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Biblioteca
{
    public partial class Libro : Form
    {
        private ConexionBiblioteca conexionDB = new ConexionBiblioteca();

        public Libro()
        {
            InitializeComponent();
            CargarLibros();
        }

        

        private void Libro_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'bibliotecaDBDataSet.Libros' Puede moverla o quitarla según sea necesario.
            this.librosTableAdapter.Fill(this.bibliotecaDBDataSet.Libros);

        }

        private void CargarLibros()
        {
            string query = "Select * from Libros";

            using (SqlConnection conn = conexionDB.Conectar())  
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Asignar los datos al DataGridView
                dataGridView1.DataSource = dt;
            }
        }

        private void agregar_libros_Click(object sender, EventArgs e)
        {
            string query = "Insert Into Libros (ISBN, Titulo, Autor, Editorial, AñoPublicacion, Genero, NumeroCopias) " +
                   "values (@ISBN, @Titulo, @Autor, @Editorial, @AñoPublicacion, @Genero, @NumeroCopias)";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ISBN", textBox7.Text);
                cmd.Parameters.AddWithValue("@Titulo", textBox1.Text);
                cmd.Parameters.AddWithValue("@Autor", textBox2.Text);
                cmd.Parameters.AddWithValue("@Editorial", textBox3.Text);
                cmd.Parameters.AddWithValue("@AñoPublicacion", int.Parse(textBox4.Text));
                cmd.Parameters.AddWithValue("@Genero", textBox5.Text);
                cmd.Parameters.AddWithValue("@NumeroCopias", int.Parse(textBox6.Text));

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Libro agregado correctamente");
                    CargarLibros();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al agregar el libro: " + ex.Message);
                }
            }
        }
        private void eliminar_libros_Click(object sender, EventArgs e)
        {
            string query = "Delete from Libros where ISBN = @ISBN";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ISBN", textBox7.Text);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Libro eliminado correctamente");
                    CargarLibros();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar el libro: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                textBox7.Text = row.Cells["ISBN"].Value.ToString();
                textBox1.Text = row.Cells["Titulo"].Value.ToString();
                textBox2.Text = row.Cells["Autor"].Value.ToString();
                textBox3.Text = row.Cells["Editorial"].Value.ToString();
                textBox4.Text = row.Cells["AñoPublicacion"].Value.ToString();
                textBox5.Text = row.Cells["Genero"].Value.ToString();
                textBox6.Text = row.Cells["NumeroCopias"].Value.ToString();
            }
        }

        private void editar_libros_Click(object sender, EventArgs e)
        {
            string query = "Update Libros set Titulo = @Titulo, Autor = @Autor, Editorial = @Editorial, " +
                   "AñoPublicacion = @AñoPublicacion, Genero = @Genero, NumeroCopias = @NumeroCopias " +
                   "where ISBN = @ISBN";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ISBN", textBox7.Text);
                cmd.Parameters.AddWithValue("@Titulo", textBox1.Text);
                cmd.Parameters.AddWithValue("@Autor", textBox2.Text);
                cmd.Parameters.AddWithValue("@Editorial", textBox3.Text);
                cmd.Parameters.AddWithValue("@AñoPublicacion", int.Parse(textBox4.Text));
                cmd.Parameters.AddWithValue("@Genero", textBox5.Text);
                cmd.Parameters.AddWithValue("@NumeroCopias", int.Parse(textBox6.Text));

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Libro actualizado correctamente");
                    CargarLibros();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar el libro: " + ex.Message);
                }
            }
        }

        
        

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
