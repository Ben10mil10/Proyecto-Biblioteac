﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Biblioteca
{
    public partial class Usuario : Form
    {

        private ConexionBiblioteca conexionDB = new ConexionBiblioteca();

        public Usuario()
        {
            InitializeComponent();
            CargarUsuarios();
        }


        private void Usuario_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'bibliotecaDBDataSet.Usuarios' Puede moverla o quitarla según sea necesario.
            this.usuariosTableAdapter.Fill(this.bibliotecaDBDataSet.Usuarios);

        }

        private void CargarUsuarios()
        {
            string query = "Select * from Usuarios";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Asignar los datos al DataGridView
                dataGridView1.DataSource = dt;
            }
        }

       

        private void agregar_libros_Click(object sender, EventArgs e)
        {
            string query = "Insert Into Usuarios (Nombre, Apellido, Email, Telefono) " +
                   "values (@Nombre, @Apellido, @Email, @Telefono)";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", textBox7.Text);
                cmd.Parameters.AddWithValue("@Apellido", textBox1.Text);
                cmd.Parameters.AddWithValue("@Email", textBox2.Text);
                cmd.Parameters.AddWithValue("@Telefono", textBox3.Text);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Usuario agregado correctamente");
                    CargarUsuarios();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al agregar el usuario: " + ex.Message);
                }
            }
        }

        private void eliminar_libros_Click(object sender, EventArgs e)
        {
            string query = "Delete from Usuarios where Nombre = @Nombre and Apellido = @Apellido";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", textBox7.Text);
                cmd.Parameters.AddWithValue("@Apellido", textBox1.Text);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Usuario eliminado correctamente");
                    CargarUsuarios();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar usuario: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                textBox7.Text = row.Cells[1].Value.ToString();
                textBox1.Text = row.Cells[2].Value.ToString();
                textBox2.Text = row.Cells[3].Value.ToString();
                textBox3.Text = row.Cells[4].Value.ToString();
            }
        }

        private void editar_libros_Click(object sender, EventArgs e)
        {
            string query = "Update Usuarios set Nombre = @Nombre, Apellido = @Apellido, Email = @Email, " +
                   "Telefono = @Telefono where Nombre = @Nombre and Apellido = @Apellido";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", textBox7.Text);
                cmd.Parameters.AddWithValue("@Apellido", textBox1.Text);
                cmd.Parameters.AddWithValue("@Email", textBox2.Text);
                cmd.Parameters.AddWithValue("@Telefono", textBox3.Text);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Libro actualizado correctamente");
                    CargarUsuarios();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar el libro: " + ex.Message);
                }
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
